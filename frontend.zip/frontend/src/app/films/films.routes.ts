import {Routes} from '@angular/router';
import {FilmsComponent} from './films.component';

export const filmsRoutes: Routes = [
  {
    path: 'home',
    component: FilmsComponent
  }
];
