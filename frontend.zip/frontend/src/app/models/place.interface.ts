export interface IPlace {
  id?: any;
  numeroLigne?: number;
  numeroColonne?: number;
  isDisponible?: boolean;
}
