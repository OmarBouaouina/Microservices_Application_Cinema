export interface IDeleteDTOInterface {
  id?: any;
  titre?: string;
  isDeleted?: boolean;
}
